package datamanagement;

import java.util.*;

import java.io.IOException;

public interface FileArticleReader {
	public void read() throws IOException;
}
