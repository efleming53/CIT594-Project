package edu.upenn.cit5940.datamanagement;

import java.util.*;

import java.io.IOException;

public interface FileArticleReader {
	public void read() throws IOException;
}