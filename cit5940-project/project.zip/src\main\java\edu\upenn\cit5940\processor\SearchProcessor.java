package edu.upenn.cit5940.processor;

import java.util.*;

import edu.upenn.cit5940.common.dto.*;
import edu.upenn.cit5940.datamanagement.*;


import java.time.LocalTime;

public class SearchProcessor {
	
	private final DataRepository dr;
	
	public SearchProcessor(DataRepository dr) {
		this.dr = dr;
	}
	

	
	public List<String> articlesContainingAllKeywords(String[] words){
		
		Map<String, Set<String>> map = dr.getSearchMap();
		Set<String> titles = dr.getArticleTitleSet();

		for (int i = 0; i < words.length; i++) {
			String word = words[i];
			
			if (StopWords.WORDS.contains(word)) {
				continue;
			}
			
			if (!map.containsKey(word)) {
				//logger
				return new ArrayList<>();
			}
			
			Set<String> wordTitles = map.get(word);
			titles.retainAll(wordTitles);
		}
		
		List<String> titlesList = new ArrayList<>(titles);
		//logger
		return titlesList;
	}
	
	//TODO: Make more efficient, trie traversal
	public List<String> allWordsFromPrefix(String prefix){
		
		Trie trie = dr.getPrefixTrie();
		List<String> allWords = trie.allWords();
		List<String> prefixWords = new ArrayList<>();
		
		for (int i = 0; i < allWords.size(); i++) {
			String word = allWords.get(i);
			if (word.startsWith(prefix)) {
				prefixWords.add(word);
			}
		}
		//logger
		return prefixWords;
	}
	
	public Integer getNumberOfArticles() {
		Set<String> titles = dr.getArticleTitleSet();	
		return titles.size();
	}

}